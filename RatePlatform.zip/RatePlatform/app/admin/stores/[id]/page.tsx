import { StoreDetails } from "@/components/admin/store-details"

interface StoreDetailsPageProps {
  params: {
    id: string
  }
}

export default function StoreDetailsPage({ params }: StoreDetailsPageProps) {
  return <StoreDetails storeId={params.id} />
}
