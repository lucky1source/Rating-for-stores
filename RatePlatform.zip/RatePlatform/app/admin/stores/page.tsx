import { StoresList } from "@/components/admin/stores-list"

export default function StoresPage() {
  return <StoresList />
}
