import { AddStoreForm } from "@/components/admin/add-store-form"

export default function AddStorePage() {
  return <AddStoreForm />
}
