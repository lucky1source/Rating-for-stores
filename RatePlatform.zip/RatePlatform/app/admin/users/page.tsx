import { UsersList } from "@/components/admin/users-list"

export default function UsersPage() {
  return <UsersList />
}
