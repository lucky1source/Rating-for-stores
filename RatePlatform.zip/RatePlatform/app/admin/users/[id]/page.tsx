import { UserDetails } from "@/components/admin/user-details"

interface UserDetailsPageProps {
  params: {
    id: string
  }
}

export default function UserDetailsPage({ params }: UserDetailsPageProps) {
  return <UserDetails userId={params.id} />
}
