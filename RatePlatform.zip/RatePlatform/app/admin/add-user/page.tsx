import { AddUserForm } from "@/components/admin/add-user-form"

export default function AddUserPage() {
  return <AddUserForm />
}
